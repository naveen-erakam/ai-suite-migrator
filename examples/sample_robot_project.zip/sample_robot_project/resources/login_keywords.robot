*** Settings ***
Library     SeleniumLibrary
Resource    ../config/variables.robot

*** Keywords ***
Open Login Page
    Open Browser    ${BASE_URL}    ${BROWSER}
    Maximize Browser Window
    Title Should Be    Swag Labs

Login With Credentials
    [Arguments]    ${username}    ${password}
    Input Text      id=user-name    ${username}
    Input Password  id=password     ${password}
    Click Button    id=login-button

Verify Login Success
    Wait Until Element Is Visible    css=.title    timeout=${TIMEOUT}
    Element Should Contain           css=.title    Products

Verify Login Error
    [Arguments]    ${expected_msg}
    Wait Until Element Is Visible    css=[data-test='error']    timeout=${TIMEOUT}
    Element Should Contain           css=[data-test='error']    ${expected_msg}

Close Session
    Close All Browsers
