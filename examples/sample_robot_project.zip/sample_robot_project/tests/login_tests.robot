*** Settings ***
Documentation       Login test suite for SauceDemo
Resource            ../resources/login_keywords.robot
Suite Setup         Open Login Page
Suite Teardown      Close Session
Test Teardown       Run Keyword If Test Failed    Capture Page Screenshot    EMBED

*** Test Cases ***
TC001 - Valid Login Redirects To Products Page
    [Documentation]    Verify standard_user login shows Products page
    [Tags]    smoke    login    positive    critical
    Login With Credentials    ${VALID_USER}    ${VALID_PASS}
    Verify Login Success

TC002 - Locked User Sees Error Message
    [Documentation]    Verify locked_out_user sees locked error
    [Tags]    regression    login    negative
    Login With Credentials    ${LOCKED_USER}    ${VALID_PASS}
    Verify Login Error    Sorry, this user has been locked out

TC003 - Empty Credentials Show Required Error
    [Documentation]    Verify empty form shows validation error
    [Tags]    regression    login    negative    validation
    Login With Credentials    ${EMPTY}    ${EMPTY}
    Verify Login Error    Username is required

TC004 - Wrong Password Shows Error
    [Documentation]    Verify wrong password triggers error
    [Tags]    regression    login    negative
    Login With Credentials    ${VALID_USER}    wrong_password
    Verify Login Error    Username and password do not match
