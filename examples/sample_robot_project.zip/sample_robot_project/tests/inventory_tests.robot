*** Settings ***
Documentation       Inventory/Products page test suite
Resource            ../resources/login_keywords.robot
Suite Setup         Run Keywords    Open Login Page
...                 AND             Login With Credentials    ${VALID_USER}    ${VALID_PASS}
Suite Teardown      Close Session

*** Variables ***
${ADD_TO_CART_BTN}      css=[data-test^='add-to-cart']
${CART_BADGE}           css=.shopping_cart_badge
${SORT_DROPDOWN}        css=[data-test='product_sort_container']

*** Test Cases ***
TC005 - Products Page Shows Six Items
    [Documentation]    Verify inventory shows exactly 6 products
    [Tags]    smoke    inventory    positive
    ${count}=    Get Element Count    css=.inventory_item
    Should Be Equal As Integers    ${count}    6

TC006 - Add To Cart Updates Badge Count
    [Documentation]    Verify cart badge updates to 1 after adding product
    [Tags]    regression    cart    positive
    Click Element     ${ADD_TO_CART_BTN}
    Wait Until Element Is Visible    ${CART_BADGE}    timeout=${TIMEOUT}
    Element Text Should Be    ${CART_BADGE}    1

TC007 - Sort Dropdown Changes Product Order
    [Documentation]    Verify sort by price low-high reorders products
    [Tags]    regression    inventory    positive
    Select From List By Value    ${SORT_DROPDOWN}    lohi
    ${count}=    Get Element Count    css=.inventory_item
    Should Be Equal As Integers    ${count}    6
