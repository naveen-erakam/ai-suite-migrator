*** Variables ***
${BROWSER}          chrome
${BASE_URL}         https://www.saucedemo.com
${TIMEOUT}          30s
${VALID_USER}       standard_user
${VALID_PASS}       secret_sauce
${LOCKED_USER}      locked_out_user
